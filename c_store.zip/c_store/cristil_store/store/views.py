from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.http import JsonResponse
from django.contrib import messages
from .models import Category, Product, Cart, CartItem, Testimonial, Order, OrderItem, Offer
from django.db.models import Q
from datetime import datetime, date
from django.core.paginator import Paginator

def is_admin(user):
    return user.is_staff

def home(request):
    products = Product.objects.all()
    testimonials = Testimonial.objects.filter(is_approved=True)
    if request.method == 'POST':
        author = request.POST.get('author')
        content = request.POST.get('content')
        Testimonial.objects.create(author=author, content=content, is_approved=False)
        messages.success(request, 'تم إرسال رأيك بنجاح، سيتم مراجعته قريباً.')
        return redirect('store:home')
    return render(request, 'store/home.html', {'products': products, 'testimonials': testimonials})

@login_required
def gallery(request):
    categories = Category.objects.all()
    products = Product.objects.all()
    category = request.GET.get('category')
    color = request.GET.get('color')
    min_price = request.GET.get('min_price')
    max_price = request.GET.get('max_price')

    if category:
        products = products.filter(category__name=category)
    if color:
        products = products.filter(color=color)
    if min_price:
        products = products.filter(price__gte=min_price)
    if max_price:
        products = products.filter(price__lte=max_price)

    return render(request, 'store/gallery.html', {'products': products, 'categories': categories})

@login_required
def offers(request):
    offers = Offer.objects.all()
    return render(request, 'store/offers.html', {'offers': offers})

@login_required
def cart(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart_items = CartItem.objects.filter(cart=cart)
    total_price = sum(
        (item.offer.price if item.offer else item.product.price) * item.quantity 
        for item in cart_items
    )
    
    for item in cart_items:
        item.item_total = (
            item.offer.price if item.offer else item.product.price
        ) * item.quantity
    
    return render(request, 'store/cart.html', {
        'cart_items': cart_items,
        'total_price': total_price
    })

@login_required
def add_to_cart(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        offer_id = request.POST.get('offer_id')
        quantity = int(request.POST.get('quantity', 1))
        
        cart, created = Cart.objects.get_or_create(user=request.user)
        
        if product_id:
            product = get_object_or_404(Product, id=product_id)
            cart_item, item_created = CartItem.objects.get_or_create(
                cart=cart, product=product, offer=None
            )
            if not item_created:
                cart_item.quantity += quantity
                cart_item.save()
            return JsonResponse({'message': 'تم إضافة المنتج للسلة'})
        
        if offer_id:
            offer = get_object_or_404(Offer, id=offer_id)
            cart_item, item_created = CartItem.objects.get_or_create(
                cart=cart, offer=offer, product=None
            )
            if not item_created:
                cart_item.quantity += quantity
                cart_item.save()
            return JsonResponse({'message': 'تم إضافة العرض للسلة'})
        
    return JsonResponse({'error': 'طلب غير صالح'}, status=400)

@login_required
def remove_from_cart(request, item_id):
    cart_item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    cart_item.delete()
    return redirect('store:cart')

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            request.session['last_login'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            if user.is_superuser:
                request.session['is_admin'] = True
            request.session.modified = True
            next_url = request.GET.get('next', '')
            if next_url:
                return redirect(next_url)
            return redirect('store:home')
        else:
            messages.error(request, 'اسم المستخدم أو كلمة المرور غير صحيحة.')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

def signup(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Specify the backend explicitly
            login(request, user, backend='django.contrib.auth.backends.ModelBackend')
            request.session['signup_time'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            request.session.modified = True
            return redirect('store:home')
        else:
            for field, errors in form.errors.items():
                for error in errors:
                    messages.error(request, f"{field}: {error}")
    else:
        form = UserCreationForm()
    return render(request, 'store/signup.html', {'form': form})

@login_required
def logout_view(request):
    logout(request)
    return redirect('store:home')

@login_required
@user_passes_test(is_admin)
def admin_page(request):
    if request.method == 'POST':
        is_ajax = request.headers.get('X-Requested-With') == 'XMLHttpRequest'

        # Add Category
        if 'add_category' in request.POST:
            name = request.POST.get('category_name')
            if Category.objects.filter(name=name).exists():
                messages.error(request, 'هذا النوع موجود بالفعل.')
            else:
                Category.objects.create(name=name)
                messages.success(request, 'تم إضافة النوع بنجاح.')

        # Edit Category
        elif 'edit_category' in request.POST:
            category_id = request.POST.get('category_id')
            name = request.POST.get('category_name')
            category = get_object_or_404(Category, id=category_id)
            if Category.objects.filter(name=name).exclude(id=category_id).exists():
                messages.error(request, 'هذا النوع موجود بالفعل.')
            else:
                category.name = name
                category.save()
                messages.success(request, 'تم تعديل النوع بنجاح.')

        # Delete Category
        elif 'delete_category' in request.POST:
            category_id = request.POST.get('category_id')
            category = get_object_or_404(Category, id=category_id)
            if Product.objects.filter(category=category).exists():
                message = 'لا يمكن حذف النوع لأنه مرتبط بمنتجات.'
                if is_ajax:
                    return JsonResponse({'success': False, 'message': message})
                messages.error(request, message)
            else:
                try:
                    category.delete()
                    message = 'تم حذف النوع بنجاح.'
                    if is_ajax:
                        return JsonResponse({'success': True, 'message': message})
                    messages.success(request, message)
                except Exception as e:
                    message = f'حدث خطأ أثناء الحذف: {str(e)}'
                    if is_ajax:
                        return JsonResponse({'success': False, 'message': message})
                    messages.error(request, message)

        # Add Product
        elif 'add_product' in request.POST:
            name = request.POST.get('name')
            description = request.POST.get('description')
            price = request.POST.get('price')
            image = request.FILES.get('image')
            category_id = request.POST.get('category')
            color = request.POST.get('color')
            category = get_object_or_404(Category, id=category_id)
            Product.objects.create(
                name=name, description=description, price=price, image=image,
                category=category, color=color or None
            )
            messages.success(request, 'تم إضافة المنتج بنجاح.')

        # Edit Product
        elif 'edit_product' in request.POST:
            product_id = request.POST.get('product_id')
            product = get_object_or_404(Product, id=product_id)
            product.name = request.POST.get('name')
            product.description = request.POST.get('description')
            product.price = request.POST.get('price')
            if request.FILES.get('image'):
                product.image = request.FILES.get('image')
            product.category = get_object_or_404(Category, id=request.POST.get('category'))
            product.color = request.POST.get('color') or None
            product.save()
            messages.success(request, 'تم تعديل المنتج بنجاح.')

        # Delete Product
        elif 'delete_product' in request.POST:
            product_id = request.POST.get('product_id')
            product = get_object_or_404(Product, id=product_id)
            try:
                product.delete()
                message = 'تم حذف المنتج بنجاح.'
                if is_ajax:
                    return JsonResponse({'success': True, 'message': message})
                messages.success(request, message)
            except Exception as e:
                message = f'حدث خطأ أثناء الحذف: {str(e)}'
                if is_ajax:
                    return JsonResponse({'success': False, 'message': message})
                messages.error(request, message)

        # Add Offer
        elif 'add_offer' in request.POST:
            name = request.POST.get('name')
            description = request.POST.get('description')
            price = request.POST.get('price')
            product_ids = request.POST.getlist('products')
            if not product_ids:
                messages.error(request, 'يجب اختيار منتج واحد على الأقل.')
            else:
                offer = Offer.objects.create(
                    name=name, description=description, price=price
                )
                offer.products.set(product_ids)
                messages.success(request, 'تم إضافة العرض بنجاح.')

        # Edit Offer
        elif 'edit_offer' in request.POST:
            offer_id = request.POST.get('offer_id')
            offer = get_object_or_404(Offer, id=offer_id)
            offer.name = request.POST.get('name')
            offer.description = request.POST.get('description')
            offer.price = request.POST.get('price')
            product_ids = request.POST.getlist('products')
            if not product_ids:
                messages.error(request, 'يجب اختيار منتج واحد على الأقل.')
            else:
                offer.products.set(product_ids)
                offer.save()
                messages.success(request, 'تم تعديل العرض بنجاح.')

        # Delete Offer
        elif 'delete_offer' in request.POST:
            offer_id = request.POST.get('offer_id')
            offer = get_object_or_404(Offer, id=offer_id)
            try:
                offer.delete()
                message = 'تم حذف العرض بنجاح.'
                if is_ajax:
                    return JsonResponse({'success': True, 'message': message})
                messages.success(request, message)
            except Exception as e:
                message = f'حدث خطأ أثناء الحذف: {str(e)}'
                if is_ajax:
                    return JsonResponse({'success': False, 'message': message})
                messages.error(request, message)

        # Edit Order
        elif 'edit_order' in request.POST:
            order_id = request.POST.get('order_id')
            status = request.POST.get('status')
            order = get_object_or_404(Order, id=order_id)
            order.status = status
            order.save()
            messages.success(request, 'تم تعديل حالة الطلب بنجاح.')

        # Delete Order
        elif 'delete_order' in request.POST:
            order_id = request.POST.get('order_id')
            order = get_object_or_404(Order, id=order_id)
            try:
                order.delete()
                message = 'تم حذف الطلب بنجاح.'
                if is_ajax:
                    return JsonResponse({'success': True, 'message': message})
                messages.success(request, message)
            except Exception as e:
                message = f'حدث خطأ أثناء الحذف: {str(e)}'
                if is_ajax:
                    return JsonResponse({'success': False, 'message': message})
                messages.error(request, message)

        # Approve Testimonial
        elif 'approve_testimonial' in request.POST:
            testimonial_id = request.POST.get('testimonial_id')
            testimonial = get_object_or_404(Testimonial, id=testimonial_id)
            testimonial.is_approved = True
            testimonial.save()
            messages.success(request, 'تم الموافقة على الرأي بنجاح.')

        # Reject Testimonial
        elif 'reject_testimonial' in request.POST:
            testimonial_id = request.POST.get('testimonial_id')
            testimonial = get_object_or_404(Testimonial, id=testimonial_id)
            testimonial.is_approved = False  # Corrected line
            testimonial.save()
            messages.success(request, 'تم رفض الرأي بنجاح.')

        # Delete Testimonial
        elif 'delete_testimonial' in request.POST:
            testimonial_id = request.POST.get('testimonial_id')
            testimonial = get_object_or_404(Testimonial, id=testimonial_id)
            try:
                testimonial.delete()
                message = 'تم حذف الرأي بنجاح.'
                if is_ajax:
                    return JsonResponse({'success': True, 'message': message})
                messages.success(request, message)
            except Exception as e:
                message = f'حدث خطأ أثناء الحذف: {str(e)}'
                if is_ajax:
                    return JsonResponse({'success': False, 'message': message})
                messages.error(request, message)

        if is_ajax:
            # Extract the latest message for AJAX response
            for message in messages.get_messages(request):
                return JsonResponse({
                    'success': message.tags == 'success',
                    'message': str(message)
                })
            return JsonResponse({
                'success': True,
                'message': 'تمت العملية بنجاح'
            })

        return redirect('store:admin_page')

    categories = Category.objects.all()
    products = Product.objects.all()
    orders = Order.objects.all()
    offers = Offer.objects.all()
    testimonials = Testimonial.objects.all()

    # Filter orders by date
    order_date = request.GET.get('order_date')
    if order_date:
        try:
            selected_date = datetime.strptime(order_date, '%Y-%m-%d').date()
            orders = orders.filter(created_at__date=selected_date)
        except ValueError:
            messages.error(request, 'تاريخ غير صالح.')

    return render(request, 'store/admin_page.html', {
        'categories': categories,
        'products': products,
        'orders': orders,
        'offers': offers,
        'testimonials': testimonials,
        'order_date': order_date
    })

@login_required
def my_orders(request):
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'store/my_orders.html', {'orders': orders})

def get_testimonials(request):
    page = int(request.GET.get('page', 1))
    # Order testimonials by a specific field (e.g., created_at or id)
    testimonials = Testimonial.objects.filter(is_approved=True).order_by('-created_at')
    paginator = Paginator(testimonials, 3)
    total_pages = paginator.num_pages
    page_obj = paginator.get_page(page)
    data = [{'content': t.content, 'author': t.author} for t in page_obj]
    return JsonResponse({
        'testimonials': data,
        'total_pages': total_pages,
        'current_page': page,
        'total_testimonials': testimonials.count()
    })

@login_required
def checkout(request):
    if request.method == 'POST':
        try:
            cart = Cart.objects.get(user=request.user)
            cart_items = CartItem.objects.filter(cart=cart)
        except Cart.DoesNotExist:
            return redirect('store:cart')

        if not cart_items:
            return redirect('store:cart')

        total_price = sum(
            (item.offer.price if item.offer else item.product.price) * item.quantity 
            for item in cart_items
        )
        
        order = Order.objects.create(
            user=request.user,
            phone=request.POST['phone'],
            address=request.POST['address'],
            total_price=total_price
        )
        
        for item in cart_items:
            if item.offer:
                for product in item.offer.products.all():
                    OrderItem.objects.create(
                        order=order,
                        product=product,
                        quantity=item.quantity,
                        price=product.price
                    )
            else:
                OrderItem.objects.create(
                    order=order,
                    product=item.product,
                    quantity=item.quantity,
                    price=item.product.price
                )
        
        cart_items.delete()
        messages.success(request, 'تم إنشاء الطلب بنجاح!')
        return redirect('store:my_orders')

    return redirect('store:cart')