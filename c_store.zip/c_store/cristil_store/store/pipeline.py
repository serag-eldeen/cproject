from .models import Cart

def create_cart(strategy, details, user=None, *args, **kwargs):
    if user and not hasattr(user, 'cart'):
        Cart.objects.get_or_create(user=user)