from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

# cristil_store/urls.py
from django.http import HttpResponse

urlpatterns = [
    path('mnbvctghjnkmfhcjj/', admin.site.urls),
    path('', include('store.urls')),
    path('auth/', include('social_django.urls', namespace='social')),
    # Handle Chrome DevTools request
    path('.well-known/appspecific/com.chrome.devtools.json', lambda request: HttpResponse(status=204)),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)